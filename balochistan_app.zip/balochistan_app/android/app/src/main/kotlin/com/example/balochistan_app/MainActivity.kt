package com.example.balochistan_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
